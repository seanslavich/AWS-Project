import time
import boto3

query = 'SELECT * FROM master_table'
DATABASE = 'masterdata'

# def max_partition1(bucket: str = None,prefix: str =None):
#     response = s3_conn.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter='/')
#     #print(response['CommonPrefixes'])
#     replace_path=prefix+'date_col='
#     print(replace_path)
#     ts=[]
#     for item in response['CommonPrefixes']:
#         print(item)
#         ts.append(item['Prefix'].replace(replace_path,'').replace('/',''))
#     print(ts)
#     max_partition=max(ts)
#     print(max_partition)
#     s3_path="s3://"+bucket+"/"+prefix+"date_col="+max_partition
#     print(s3_path)
#     return s3_path


outputpath = 's3://hiring-curated-bucket/catalogtable_final/'

def lambda_handler(event, context):
    query = 'SELECT * FROM master_table'
    client = boto3.client('athena')
    # Execution
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': DATABASE
        },
        ResultConfiguration={
            'OutputLocation': outputpath,
        }
    )
    print('Athena Refresh Success!')
    return response